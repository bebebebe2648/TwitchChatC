﻿using System.Collections;
using System.Collections.Generic;
using System;
using System.Threading.Tasks;
using AsyncAwaitBestPractices;

namespace ChatBot
{
    public class Casino
    {
        public string User;         //ユーザ名
        public int Tip;             //手持ちチップ総数
        public int BETTip;          //賭けたチップ数
        public int Lucky_Num;       //当選額
        public int Total_Num;       //賭けた役の数値格納
        public int Single_Num;
        public int Pair_Num1;
        public int Pair_Num2;
        public int Dobble_Num;
        public int Tripple_Num;
        public bool First_Time;     //初めての参加か？

        //この2つはどちらかだけでいい？
        public bool Join;           //ゲームに参加してるかどうか
        public bool BET;            //賭けたかどうか
        public bool Ready;          //準備完了かどうか
        public bool Lucky;          //当選したかどうか

        //いくらかけたか？
        public int Small_BET_Num = 0;
        public int Big_BET_Num = 0;
        public int Total_BET_Num = 0;
        public int Single_BET_Num = 0;
        public int Pair_BET_Num = 0;
        public int Dobble_BET_Num = 0;
        public int AnyTripple_BET_Num = 0;
        public int Tripple_BET_Num = 0;

        //役
        public bool Small;
        public bool Big;
        public bool Total;
        public bool Single;
        public bool Pair1;
        public bool Pair2;
        public bool Dobble;
        public bool AnyTripple;
        public bool Tripple;

        public Casino(string User, int Tip, int BETTip, int Lucky_Num,
                      int Total_Num, int Single_Num, int Pair_Num1, int Pair_Num2, int Dobble_Num, int Tripple_Num,
                      bool First_Time, bool Join, bool BET, bool Ready, bool Lucky,
                      int Small_BET_Num, int Big_BET_Num, int Total_BET_Num, int Single_BET_Num, int Pair_BET_Num, int Dobble_BET_Num, int AnyTripple_BET_Num, int Tripple_BET_Num,
                      bool Small, bool Big, bool Total, bool Single, bool Pair1, bool Pair2, bool Dobble, bool AnyTripple, bool Tripple)
        {
            this.User = User;
            this.Tip = Tip;
            this.BETTip = BETTip;
            this.Lucky_Num = Lucky_Num;

            //int
            this.Total_Num = Total_Num;
            this.Single_Num = Single_Num;
            this.Pair_Num1 = Pair_Num1;
            this.Pair_Num2 = Pair_Num2;
            this.Dobble_Num = Dobble_Num;
            this.Tripple_Num = Tripple_Num;
            this.First_Time = First_Time;

            //bool
            this.Join = Join;
            this.BET = BET;
            this.Ready = Ready;
            this.Lucky = Lucky;

            //役ごとにいくらかけたか
            this.Small_BET_Num = Small_BET_Num;
            this.Big_BET_Num = Big_BET_Num;
            this.Total_BET_Num = Total_BET_Num;
            this.Single_BET_Num = Single_BET_Num;
            this.Pair_BET_Num = Pair_BET_Num;
            this.Dobble_BET_Num = Dobble_BET_Num;
            this.AnyTripple_BET_Num = AnyTripple_BET_Num;
            this.Tripple_BET_Num = Tripple_BET_Num;

            //bool
            this.Small = Small;
            this.Big = Big;
            this.Total = Total;
            this.Single = Single;
            this.Pair1 = Pair1;
            this.Pair2 = Pair2;
            this.Dobble = Dobble;
            this.AnyTripple = AnyTripple;
            this.Tripple = Tripple;
        }
    }

    class Program
    {
        public static List<Casino> Member = new List<Casino>();
        public List<string> Role_List = new List<string>();

        public bool Dice_Roll = false;

        string Kick_User = "";

        public int BET_Num = 0;

        static async Task Main(string[] args)
        {
            string password = "oauth:stvg0pci2xx1jlm3sunmykdqkps84f";
            string botUsername = "akangogosub";

            var twitchBot = new TwitchBot(botUsername, password);
            twitchBot.Start().SafeFireAndForget();
            //We could .SafeFireAndForget() these two calls if we want to
            await twitchBot.JoinChannel("akangogo");
            await twitchBot.SendMessage("akangogo", "Hey my bot has started up");

            twitchBot.OnMessage += async (sender, twitchChatMessage) =>
            {
                Console.WriteLine($"{twitchChatMessage.Sender} said '{twitchChatMessage.Message}'");
                //Listen for !hey command
                if (twitchChatMessage.Message.StartsWith("!hey"))
                {
                    await twitchBot.SendMessage(twitchChatMessage.Channel, $"/w {twitchChatMessage.Sender} Hi");
                }

                if (twitchChatMessage.Message.StartsWith("!ゲームヘルプ"))
                {
                    if (twitchChatMessage.Sender == botUsername)
                    {
                        await twitchBot.SendMessage(twitchChatMessage.Channel, $" {twitchChatMessage.Sender} " +
                                     $"カジノゲーム「大小」へようこそ！" +
                                     "このゲームはTwitchのチャットを利用します。" +
                                     "まずは【入会】コマンドから登録。" +
                                     "【参加】によりゲームに参加して、" +
                                     "「役」を予想・入力してから【BET 数値】を入力。" +
                                     "全員の予想が完了しているか【準備】で確認してから、" +
                                     "いよいよ【ダイスロール】です。" +
                                     "各役は【役一覧】コマンドから確認できます。" +
                                     "【コマンド一覧】もご確認ください。" +
                                     "各コマンドは【】内を入力してください。");

                        return;
                    }

                    else
                    {
                        await twitchBot.SendMessage(twitchChatMessage.Channel, $"/w {twitchChatMessage.Sender} " +
                                     $"カジノゲーム「大小」へようこそ！" +
                                     "このゲームはTwitchのチャットを利用します。" +
                                     "まずは【入会】コマンドから登録。" +
                                     "【参加】によりゲームに参加して、" +
                                     "「役」を予想・入力してから【BET 数値】を入力。" +
                                     "全員の予想が完了しているか【準備】で確認してから、" +
                                     "いよいよ【ダイスロール】です。" +
                                     "各役は【役一覧】コマンドから確認できます。" +
                                     "【コマンド一覧】もご確認ください。" +
                                     "各コマンドは【】内を入力してください。");

                        return;
                    }
                }

                if (twitchChatMessage.Message.StartsWith("!入会"))
                {
                    //入会者0の場合
                    if (Member.Count == 0)
                    {
                        if (twitchChatMessage.Sender == botUsername)
                        {
                            Member.Add(new Casino(twitchChatMessage.Sender, 5000, 0, 0, 0, 0, 0, 0, 0, 0,
                                   true, false, false, false, false,
                                   0, 0, 0, 0, 0, 0, 0, 0,
                                   false, false, false, false, false, false, false, false, false));

                            await twitchBot.SendMessage(twitchChatMessage.Channel, $"/w {twitchChatMessage.Sender} " +
                                             $"ご入会ありがとうございます。" +
                                             "初回チップ5000枚をプレゼントさせていただきました。" +
                                             "ゲームに【参加】してお楽しみください。");

                            await twitchBot.SendMessage(twitchChatMessage.Channel, $" {twitchChatMessage.Sender} " +
                                             $"ご入会ありがとうございます。" +
                                             "初回チップ5000枚をプレゼントさせていただきました。" +
                                             "ゲームに【参加】してお楽しみください。");
                            return;
                        }

                        else
                        {
                            Member.Add(new Casino(twitchChatMessage.Sender, 5000, 0, 0, 0, 0, 0, 0, 0, 0,
                                   true, false, false, false, false,
                                   0, 0, 0, 0, 0, 0, 0, 0,
                                   false, false, false, false, false, false, false, false, false));

                            await twitchBot.SendMessage(twitchChatMessage.Channel, $"/w {twitchChatMessage.Sender} " +
                                             $"ご入会ありがとうございます。" +
                                             "初回チップ5000枚をプレゼントさせていただきました。" +
                                             "ゲームに【参加】してお楽しみください。");
                            return;
                        }
                    }

                    //入会者がいる場合
                    else
                    {
                        //入会リストから重複チェック
                        for (int i = 0; i < Member.Count; i++)
                        {
                            if (Member[i].User == twitchChatMessage.Sender)
                            {
                                await twitchBot.SendMessage(twitchChatMessage.Channel, $" {twitchChatMessage.Sender} " +
                                             $"すでに入会済みです。");
                                return;
                            }
                        }

                        if (twitchChatMessage.Sender == botUsername)
                        {
                            Member.Add(new Casino(twitchChatMessage.Sender, 5000, 0, 0, 0, 0, 0, 0, 0, 0,
                                   true, false, false, false, false,
                                   0, 0, 0, 0, 0, 0, 0, 0,
                                   false, false, false, false, false, false, false, false, false));

                            await twitchBot.SendMessage(twitchChatMessage.Channel, $"/w {twitchChatMessage.Sender} " +
                                             $"ご入会ありがとうございます。" +
                                             "初回チップ5000枚をプレゼントさせていただきました。" +
                                             "ゲームに【参加】してお楽しみください。");

                            await twitchBot.SendMessage(twitchChatMessage.Channel, $" {twitchChatMessage.Sender} " +
                                             $"ご入会ありがとうございます。" +
                                             "初回チップ5000枚をプレゼントさせていただきました。" +
                                             "ゲームに【参加】してお楽しみください。");
                            return;
                        }

                        else
                        {
                            Member.Add(new Casino(twitchChatMessage.Sender, 5000, 0, 0, 0, 0, 0, 0, 0, 0,
                                   true, false, false, false, false,
                                   0, 0, 0, 0, 0, 0, 0, 0,
                                   false, false, false, false, false, false, false, false, false));

                            await twitchBot.SendMessage(twitchChatMessage.Channel, $"/w {twitchChatMessage.Sender} " +
                                             $"ご入会ありがとうございます。" +
                                             "初回チップ5000枚をプレゼントさせていただきました。" +
                                             "ゲームに【参加】してお楽しみください。");
                            return;
                        }
                    }
                }

                if (twitchChatMessage.Message.StartsWith("!参加"))
                {
                    for (int i = 0; i < Member.Count; i++)
                    {
                        //配信者
                        if (Member[i].User == twitchChatMessage.Sender && twitchChatMessage.Sender == botUsername)
                        {
                            //ゲームに参加
                            Member[i].Join = true;

                            if (Member[i].First_Time)
                            {
                                await twitchBot.SendMessage(twitchChatMessage.Channel, $" {twitchChatMessage.Sender} がゲームに参加しました。" +
                                                 "まず、賭ける役を入力してください。" +
                                                 "【役一覧】から一覧を確認できます。" +
                                                 "【】内を入力してください。");
                                
                                return;
                            }

                            else
                            {
                                await twitchBot.SendMessage(twitchChatMessage.Channel, $" {twitchChatMessage.Sender} がゲームに参加しました。" +
                                                 "【役一覧】から一覧を確認できます。");
                                
                                return;
                            }
                        }

                        //リスナー
                        else if (Member[i].User == twitchChatMessage.Sender && twitchChatMessage.Sender != botUsername)
                        {
                            //ゲームに参加
                            Member[i].Join = true;

                            if (Member[i].First_Time)
                            {
                                await twitchBot.SendMessage(twitchChatMessage.Channel, $"/w {twitchChatMessage.Sender} がゲームに参加しました。" +
                                                 "まず、賭ける役を入力してください。" +
                                                 "【役一覧】から一覧を確認できます。" +
                                                 "【】内を入力してください。");
                                
                                return;
                            }

                            else
                            {
                                await twitchBot.SendMessage(twitchChatMessage.Channel, $"/w {twitchChatMessage.Sender} " +
                                                 $"がゲームに参加しました。" +
                                                 "【役一覧】から一覧を確認できます。");
                                
                                return;
                            }
                        }
                    }

                    await twitchBot.SendMessage(twitchChatMessage.Channel, $" {twitchChatMessage.Sender} " +
                                     $"ゲームに参加できません。" +
                                     "入会処理はお済ですか？");
                    
                    return;
                }
            };

            await Task.Delay(-1);
        }
    }
}
